package com.spring.user;
import com.spring.*;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.tomcat.util.net.openssl.ciphers.Authentication;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ExtendedModelMap;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
@SuppressWarnings("serial")
@Controller
@SessionAttributes({"shop","user"})
public class UserController extends ExtendedModelMap{
 
	List<Purchase> list=new ArrayList<Purchase>();
	@Autowired
	private UserService userService;
	
	@RequestMapping("/index")
	public String index() {
		return "index";
	}
	@RequestMapping("/signup")
	public String signup() {
		return "signup";
	}
	@RequestMapping("/shop")
	public String shop() {
		return "shop";
	}
	@RequestMapping("/store")
	public String store() {
		return "store";
	}
	@RequestMapping(value="/product", method=RequestMethod.GET)
	public ModelAndView product(@ModelAttribute Shop shop) {
		 List<Product> list= userService.getAllProduct(shop);
		return new ModelAndView("product","Shop",list);

	}
	@RequestMapping(value="/add", method=RequestMethod.GET)
	public ModelAndView add(@ModelAttribute Shop shop) {
		return new ModelAndView("add","Shop",shop);

	}
	@RequestMapping("/createUser")
	public ModelAndView createUser(@RequestParam("userName")String name,@RequestParam("password")String password,@RequestParam("role")String role,@RequestParam("email")String email,@RequestParam("mobileNumber")String mobileNumber,@RequestParam("address")String address)
	{
		String[] arr=address.split(",");
		Address add=new Address(Integer.parseInt(arr[0]),arr[1],arr[2],arr[3],Integer.parseInt(arr[4]));
		User user=new User(name,password,role,email,mobileNumber,add);
		userService.saveUserObj(user);
		if(role.equals("owner"))
			//return "redirect:shop.do";
			  return new ModelAndView("shop");
		else
			  return new ModelAndView("index");	
	}
	@RequestMapping("/shopDetail")
	public String shopDetail(@RequestParam("shopName")String shopName,@RequestParam("address")String address)
	{
		String[] arr=address.split(",");
		Address add=new Address(Integer.parseInt(arr[0]),arr[1],arr[2],arr[3],Integer.parseInt(arr[4]));
		//Integer id=23;
		User user=userService.findId();
		Shop shop=new Shop(user,shopName,add);
		userService.saveShopDetail(shop);
		return "index";
	}
	@RequestMapping("/addProduct" )
	public ModelAndView addProduct(@RequestParam("productName")String productName,@RequestParam("quantity")Integer quantity,@RequestParam("price")Double price,@ModelAttribute Shop shop)
	{
		Product test=userService.checkProduct(productName);
		if(test==null)
		{
			Product products=new Product(productName,quantity,price,shop);
			userService.addProduct(products);
		}
		else
		{
			Integer quan=test.getQuantity();
			Double cost=test.getPrice();
			Integer fquantity=quan+quantity;
			if(quan!=quantity ||cost!=price)
			{
				//Product products1=new Product(productName,quan,price,shop);
				userService.update(test,fquantity,price);
			}
		}
		
		return new ModelAndView("add","Shop",shop);
	}
//-----------------------------------------------------------------//
	@RequestMapping("/loginSuccess" )
	public ModelAndView loginSuccess(@RequestParam("email")String email,@RequestParam("password")String password,ModelMap model, HttpServletRequest request)
	{
	    User user=userService.checkUser(email,password);
	    if (user == null) {
			return new ModelAndView("index", "error", "UserName or Password may be wrong!!");
		} 
	    else {
			HttpSession session = request.getSession();
			session.setAttribute("loginStatus", "true");
			return new ModelAndView("redirect:checkRole.do","user",user);	
		}
	}  
	@RequestMapping("/checkRole")
	public ModelAndView checkRole(@ModelAttribute User user,HttpServletRequest request,ModelMap modelMap)
	{   
	      if(user.getRole().equals("user")) {
	    	  modelMap.put("user",user);
	    	  return new ModelAndView("user","User",user);
	      }
	      if(user.getRole().equals("owner"))
	    		{
	    			//Integer userId=u.getId();
	    			Shop shop=userService.getShop(user);
	    			if(shop==null)
	    				return new ModelAndView("signup");
	    			else {
	    				modelMap.put("shop",shop);
	    				return new ModelAndView("store","Shop",shop);
	    			}
	    			   
	    		}
	    	else
	    		return new ModelAndView("index");
	    			
	}
	//--------------------------------------------------------------------------------------------------//
	
	//carousel,navbar
	@RequestMapping("/user")
	public String user() {
		return "user";
	}
	@RequestMapping("/city")
	public String city() {
		return "city";
	}
	
	@RequestMapping("/order")
	public String order() {
		return "displayProduct";
	}
	@RequestMapping("/getShop")
	public ModelAndView getShop(@RequestParam("city")String city) {
		List<Shop> shops=userService.getAllShops(city);
		return new ModelAndView("city","Shops",shops);
		}
	@RequestMapping("/displayProduct")
	public ModelAndView displayProduct(@RequestParam("shopId")Integer shopId,HttpServletRequest request) {
		HttpSession session = request.getSession();
		session.setAttribute("shopId", shopId);
		List<Product> product=	(List<Product>)userService.displayProduct(shopId);
		return new ModelAndView("displayProduct","Product",product); 
	}	
	
	//-----------------------------------------------------//
	@RequestMapping(value = "/ordernow", method = RequestMethod.POST)
	public ModelAndView purchase(@RequestParam("prodId")Integer id,@RequestParam("quantity")Integer quantity,@ModelAttribute User user,HttpServletRequest request) {
		int count=0;
		Product product=userService.purchaseProduct(id);
		Double price=quantity*product.getPrice();
		long millis=System.currentTimeMillis();
		java.sql.Date date=new java.sql.Date(millis);
		Purchase purchase=new Purchase(user,product,quantity,price,date);
			if(list.isEmpty()) {
			list.add(purchase);}
			else
			{
				for(Purchase temp:list)
				{
					if(temp.getProduct().getProductName().equals(product.getProductName()))
					{
						price=quantity*temp.getProduct().getPrice();
						temp.setQuantity(quantity);
						temp.setPrice(price);
						count=1;
					}
				}
				if(count==0)
				{
					list.add(purchase);
				}
			}
		HttpSession session = request.getSession();
		Integer shopId=(Integer) session.getAttribute("shopId");
		return new ModelAndView("redirect:displayProduct.do","shopId",shopId);	        		
		
	}
	//---------------------------------------//
	@RequestMapping("/edit")
	public ModelAndView Edit(HttpServletRequest request) {
		HttpSession session = request.getSession();
		Integer shopId=(Integer) session.getAttribute("shopId");
		return new ModelAndView("redirect:displayProduct.do","shopId",shopId);	
    
	}
	@RequestMapping("/deleteProduct")
	public ModelAndView deleteProduct(@RequestParam("productId")Integer id)throws Exception  {
		
		for(Purchase temp:list)
		{
			if(temp.getProduct().getId().equals(id))
			{
			  list.remove(temp);
			}
		}
		return new ModelAndView("redirect:cart.do");
    
	}
	@RequestMapping("/cart")
	public ModelAndView cart() {
		return new ModelAndView("cart","Cart",list); 
    
	}
	@RequestMapping("/logout")
	public String invalid(@ModelAttribute User user,HttpSession session,SessionStatus status) {
		list.clear();
		session.invalidate();
		return "index";
    
	}
	@RequestMapping("/savePurchase")
	public ModelAndView savePurchase() {
		for(Purchase temp1:list)
		{
			Product product=userService.getProduct(temp1.getProduct().getId());
			   Integer quantity=temp1.getQuantity();
			   Integer orgquant=product.getQuantity()-quantity;
			   userService.update(product,orgquant,product.getPrice());
			userService.savePurchase(temp1);
			   
		}
		
		return new ModelAndView("cart", "error", "Product is Booked Successfully and check your cart!!");
    
	}
//------------------------------------------------//
	@RequestMapping("/orders")
	public ModelAndView orders(@ModelAttribute Shop shop) {
		List<Purchase> orders=userService.orders(shop);
		return new ModelAndView("ordersList", "list", orders);
    
	}
	
	@RequestMapping("/viewcart")
	public ModelAndView viewcart(@ModelAttribute User user) {
		List<Purchase> orders=userService.viewcart(user);
		return new ModelAndView("displaycart", "list", orders);   
	}
}
