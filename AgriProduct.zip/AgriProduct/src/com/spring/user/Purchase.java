package com.spring.user;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;
import org.springframework.beans.factory.annotation.Autowired;
@Entity
@Table(name="Purchase")
public class Purchase {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id; 
	
	@ManyToOne
	@ForeignKey(name="user")
	@Autowired
	private User user;
	
	@ManyToOne
	@ForeignKey(name="product")
	@Autowired
	private Product product;
	
	@Column(name = "quantity")
	private Integer quantity;
	
	@Column(name = "price")
	private Double price;
	
	@Column(name="date")
	private Date date;
	Purchase()
	{
		
	}
	public Purchase(Integer id, User user, Product product, Integer quantity, Double price,Date date) {
		this.id = id;
		this.user = user;
		this.product = product;
		this.quantity = quantity;
		this.price = price;
		this.date=date;
	}
	public Purchase(User user, Product product, Integer quantity, Double price,Date date) {
		this.user = user;
		this.product = product;
		this.quantity = quantity;
		this.price = price;
		this.date=date;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date=date;
	}
	
}
