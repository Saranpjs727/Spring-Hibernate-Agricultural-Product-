package com.spring.user;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Criteria;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projection;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.spring.user.User;
import com.spring.user.UserService;

import javassist.bytecode.Descriptor.Iterator;

@Service
public class UserService  {
     Criteria criteria=null;
     Criteria criteria1=null;
     @Autowired
	SessionFactory sessionFactory;
	
     @Autowired
	public void setSessionFactory(SessionFactory sessionFactory)
	{
		this.sessionFactory=sessionFactory;
	}
     @Autowired
	public SessionFactory getSessionFactory()
	{
		return sessionFactory;
	}
	
 @Transactional
	public void saveUserObj(User userObj) {
		Address address=userObj.getAddress();
		sessionFactory.getCurrentSession().save(address);
		sessionFactory.getCurrentSession().save(userObj);
	}
 @Transactional
 public User checkUser(String email,String password)
 {
        criteria = sessionFactory.getCurrentSession().createCriteria(User.class);
		criteria.add(Restrictions.eq("email", email));
		criteria.add(Restrictions.eq("password",password));
		return (User)criteria.uniqueResult();
 
 }
@Transactional
	public void saveShopDetail(Shop shop) {
	     //User user=shop.getUser();
		Address address=shop.getAddress();
		sessionFactory.getCurrentSession().save(address);
		sessionFactory.getCurrentSession().save(shop);
	}
@Transactional
 public User findId()
 {
	criteria=sessionFactory.getCurrentSession().createCriteria(User.class);
	criteria.addOrder(Order.desc("id"));
	criteria.setMaxResults(1);
	return  (User) criteria.uniqueResult();
	
 }
@Transactional
public Shop getShop(User user)
{
	
	criteria = sessionFactory.getCurrentSession().createCriteria(Shop.class);
	criteria.add(Restrictions.eq("user", user));
	return (Shop) criteria.uniqueResult();
	
}
@Transactional
public void addProduct(Product product) {
	sessionFactory.getCurrentSession().save(product);
}
@Transactional
public Product checkProduct(String product)
{
	criteria=sessionFactory.getCurrentSession().createCriteria(Product.class);
	criteria.add(Restrictions.eq("productName", product));
	return (Product)criteria.uniqueResult();
}
@Transactional
public void update(Product products,Integer quantity,Double price)
{
	Product product=(Product) sessionFactory.getCurrentSession().get(Product.class,products.getId());
	product.setQuantity(quantity);
	product.setPrice(price);
	sessionFactory.getCurrentSession().update(product);
}
@Transactional
public List<Product> getAllProduct(Shop shops)
{
	criteria=sessionFactory.getCurrentSession().createCriteria(Product.class)
	 .add(Restrictions.eq("shop", shops));
	
	List<Product> l=criteria.list();
	return l;
}
//--------------------------------------------//
@Transactional
public List<Shop> getAllShops(String city)
{
	criteria=sessionFactory.getCurrentSession().createCriteria(Shop.class)
	.createAlias("address", "address")
	.add(Restrictions.eq("address.city",city));
	List<Shop> list=criteria.list();
	return list;
}
@Transactional
public List displayProduct(Integer shopId)
{
	criteria=sessionFactory.getCurrentSession().createCriteria(Product.class)
	.createAlias("shop", "shop")
	.add(Restrictions.eq("shop.id",shopId));
	List list=criteria.list();
	return list;
}
@Transactional
public Product purchaseProduct(Integer productId)
{
	criteria=sessionFactory.getCurrentSession().createCriteria(Product.class)
	.add(Restrictions.eq("id",productId));
	return (Product)criteria.uniqueResult();
}
@Transactional
public void purchase(Purchase purchase) {
	sessionFactory.getCurrentSession().save(purchase);
}
@Transactional
public Product getProduct(Integer productId)
{
	criteria=sessionFactory.getCurrentSession().createCriteria(Product.class);
	criteria.add(Restrictions.eq("id", productId));
	return (Product)criteria.uniqueResult();
}
@Transactional
public void savePurchase(Purchase purchase) {
	sessionFactory.getCurrentSession().save(purchase);
}
@Transactional
public List<Purchase> orders(Shop shops) {

	criteria=sessionFactory.getCurrentSession().createCriteria(Purchase.class,"purchase")
		.createAlias("product","product")
		.add(Restrictions.eq("product.shop",shops));
	List<Purchase> list1=criteria.list();
	return list1;
	      
}
@Transactional
public List<Purchase> viewcart(User user) {

	criteria=sessionFactory.getCurrentSession().createCriteria(Purchase.class,"purchase")
		.add(Restrictions.eq("user",user));
	List<Purchase> list1=criteria.list();
	return list1;	      
}
}