package com.spring.user;

import java.sql.Date;

public class Orders {

	private String userName;
	private  Integer doorNo;
	private String area;
	private String city;
	private String productName;
	private Date date;
	private Double cost;
	Orders()
	{
			
	}
	public Orders(String userName, Integer doorNo, String area, String city, String productName, Date date,
			Double cost) {
		this.userName = userName;
		this.doorNo = doorNo;
		this.area = area;
		this.city = city;
		this.productName = productName;
		this.date = date;
		this.cost = cost;
	}
		
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Integer getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(Integer doorNo) {
		this.doorNo = doorNo;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Double getCost() {
		return cost;
	}
	public void setCost(Double cost) {
		this.cost = cost;
	}
	
}
