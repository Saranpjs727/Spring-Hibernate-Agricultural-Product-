package com.spring.user;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.ForeignKey;
import org.springframework.beans.factory.annotation.Autowired;
@SuppressWarnings("serial")
@Entity
@Table(name="Product")
public class Product implements Serializable{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id; 
	@Column(name = "productName")
	private String productName;
	@Column(name = "quantity")
	private Integer quantity;
	@Column(name = "price")
	private Double price;
	
	@OneToOne
	@ForeignKey(name="shop")
	@Autowired
	private Shop shop;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public Shop getShop() {
		return shop;
	}
	public void setShop(Shop shop) {
		this.shop = shop;
	}
	Product()
	{
		
	}
	public Product(Integer id, String productName, Integer quantity, Double price, Shop shop) {
		this.id = id;
		this.productName = productName;
		this.quantity = quantity;
		this.price = price;
		this.shop = shop;
	}
	public Product(String productName, Integer quantity, Double price, Shop shop) {
		this.productName = productName;
		this.quantity = quantity;
		this.price = price;
		this.shop = shop;
	}
	


	
}
